/* Load this script using conditional IE comments if you need to support IE 7 and IE 6. */

window.onload = function() {
	function addIcon(el, entity) {
		var html = el.innerHTML;
		el.innerHTML = '<span style="font-family: \'jg-functional\'">' + entity + '</span>' + html;
	}
	var icons = {
			'icon-search' : '&#xe000;',
			'icon-envelope' : '&#xe001;',
			'icon-heart' : '&#xe002;',
			'icon-star' : '&#xe003;',
			'icon-star-empty' : '&#xe004;',
			'icon-ok' : '&#xe005;',
			'icon-download' : '&#xe006;',
			'icon-download-alt' : '&#xe007;',
			'icon-file' : '&#xe008;',
			'icon-home' : '&#xe009;',
			'icon-trash' : '&#xe00a;',
			'icon-remove' : '&#xe00b;',
			'icon-zoom-in' : '&#xe00c;',
			'icon-zoom-out' : '&#xe00d;',
			'icon-upload' : '&#xe00e;',
			'icon-play-circle' : '&#xe00f;',
			'icon-repeat' : '&#xe010;',
			'icon-refresh' : '&#xe011;',
			'icon-bookmark' : '&#xe012;',
			'icon-flag' : '&#xe013;',
			'icon-check' : '&#xe014;',
			'icon-chevron-left' : '&#xe015;',
			'icon-chevron-right' : '&#xe016;',
			'icon-plus-sign' : '&#xe017;',
			'icon-minus-sign' : '&#xe018;',
			'icon-ok-sign' : '&#xe019;',
			'icon-info-sign' : '&#xe01a;',
			'icon-arrow-left' : '&#xe01b;',
			'icon-arrow-right' : '&#xe01c;',
			'icon-arrow-up' : '&#xe01d;',
			'icon-arrow-down' : '&#xe01e;',
			'icon-exclamation-sign' : '&#xe01f;',
			'icon-twitter-sign' : '&#xe020;',
			'icon-facebook-sign' : '&#xe021;',
			'icon-thumbs-up' : '&#xe022;',
			'icon-thumbs-down' : '&#xe023;',
			'icon-bookmark-empty' : '&#xe024;',
			'icon-twitter' : '&#xe025;',
			'icon-facebook' : '&#xe026;',
			'icon-circle-arrow-left' : '&#xe027;',
			'icon-circle-arrow-right' : '&#xe028;',
			'icon-circle-arrow-up' : '&#xe029;',
			'icon-circle-arrow-down' : '&#xe02a;',
			'icon-caret-down' : '&#xe02b;',
			'icon-caret-up' : '&#xe02c;',
			'icon-caret-left' : '&#xe02d;',
			'icon-caret-right' : '&#xe02e;'
		},
		els = document.getElementsByTagName('*'),
		i, attr, html, c, el;
	for (i = 0; ; i += 1) {
		el = els[i];
		if(!el) {
			break;
		}
		attr = el.getAttribute('data-icon');
		if (attr) {
			addIcon(el, attr);
		}
		c = el.className;
		c = c.match(/icon-[^\s'"]+/);
		if (c && icons[c[0]]) {
			addIcon(el, icons[c[0]]);
		}
	}
};