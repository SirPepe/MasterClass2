Aus diesem wenig gestalteten Etwas kann man mit unterschiedlichen Methoden eine Webseite formen.

Die Seite ist mit YAML-Klassen aufgebaut, YAML kann also genutzt werden. Aber man kann die Klassen natürlich auch komplett ohne YAML nutzen.
