Folgende Schritte benötigen wir, um diese Bilderliste interessant zu machen:

1. Entfernen der Listeneigenschaften
2. Einrahmung der Bilder (border, padding, background)
3. Übereinanderstapeln der Bilder
4. Transform nutzen, um die Bilder voneinander zu verschieben, leicht zu drehen
5. Aktionen, die bei bei :hover ausgeführt werden.  
